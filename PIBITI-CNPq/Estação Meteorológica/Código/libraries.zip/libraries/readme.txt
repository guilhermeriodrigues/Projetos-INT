Para informações a respeito de instalação de bibliotecas, acesso: http://www.arduino.cc/en/Guide/Libraries
